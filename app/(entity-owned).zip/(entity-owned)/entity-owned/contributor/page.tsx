"use client"

import React, { useState } from 'react';
import ContributorPage from "../../components/contributor/ContributorPage"

const Contributor = () => {

  return (
    <>
      <ContributorPage />
    </>
  )
}

export default Contributor
