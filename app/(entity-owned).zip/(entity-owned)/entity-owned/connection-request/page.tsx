import PendingRequests from "../../components/connection-requests/PendingRequests"

const ConnectionRequest = () => {
  return (
    <>
      <h1 className="margin-bottom-0">Connection Requests</h1>
      <hr style={{ margin: '1rem 0' }} />
      <PendingRequests />
    </>
  )
}

export default ConnectionRequest
