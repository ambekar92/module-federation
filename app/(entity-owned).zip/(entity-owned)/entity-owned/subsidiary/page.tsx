"use client"

import React, { useState } from 'react';
import SubsidiaryPage from "../../components/subsidiary/SubsidiaryPage"

const Subsidiaries = () => {

  return (
    <>
      <SubsidiaryPage />
    </>
  )
}

export default Subsidiaries
