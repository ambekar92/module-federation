import TransferBusiness from "@/app/(field-function)/components/transfer-business/TransferBusiness"

const TransferBusinessPage = () => {
  return (
    <TransferBusiness />
  )
}

export default TransferBusinessPage
