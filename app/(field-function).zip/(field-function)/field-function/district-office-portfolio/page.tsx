import DistrictOfficePortfolio from "@/app/(field-function)/components/district-office-portfolio/DistrictOfficePortfolio"

const DistrictOfficePortfolioPage = () => {
  return (
    <DistrictOfficePortfolio />
  )
}

export default DistrictOfficePortfolioPage
