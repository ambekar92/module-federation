import DistrictOfficeAssignment from "@/app/(field-function)/components/district-office-assignment/DistrictOfficeAssignment"

const DistrictOfficeAssignmentPage = () => {
  return (
    <DistrictOfficeAssignment />
  )
}

export default DistrictOfficeAssignmentPage
