import React from 'react'
import { UsersList } from '../../components/UsersList'

export default function Users() {
  return <UsersList />
}
